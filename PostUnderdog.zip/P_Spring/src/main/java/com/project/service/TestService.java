package com.project.service;

public interface TestService {
	public String getOne();
	public String getTwo();
}
