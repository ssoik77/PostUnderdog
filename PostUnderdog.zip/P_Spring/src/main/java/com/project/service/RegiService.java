package com.project.service;

import com.project.dto.EmployeeDto;

public interface RegiService {
	void registerEmployee(EmployeeDto employee);
}
