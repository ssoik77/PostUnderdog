package com.project.dto;

public class MemberDto {

}
